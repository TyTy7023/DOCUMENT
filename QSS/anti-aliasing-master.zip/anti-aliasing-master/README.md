# anti-aliasing
Demo for anti-aliasing techniques.
