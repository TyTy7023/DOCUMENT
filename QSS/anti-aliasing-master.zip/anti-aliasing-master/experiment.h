#ifndef ANTI_ALIASING_EXPERIMENT_H
#define ANTI_ALIASING_EXPERIMENT_H

#include <SDL2/SDL_pixels.h>
#include "demo.h"

float compare_canvasses(Canvas *A, Canvas *B);

#endif //ANTI_ALIASING_EXPERIMENT_H
